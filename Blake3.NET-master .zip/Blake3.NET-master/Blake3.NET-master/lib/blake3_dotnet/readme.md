# blake3_dotnet

BLAKE3 Rust libraries compiled to native and exposed as plain shared libraries.

## How to build?

You need to have [`rustup`](https://rustup.rs/) installed

Run one of the `build*` scripts (e.g `build-win-x64.ps1` or `build-linux-x64.sh`).